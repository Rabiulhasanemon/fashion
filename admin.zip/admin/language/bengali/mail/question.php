<?php
// Text
$_['text_subject']	= '%s - has replied to your question';
$_['text_question'] = "Question: %s";
$_['text_answer']   = "Answer: %s";
$_['text_product']  = "Product: %s";