<?php
// Text
$_['text_subject']	= '%s - Product Update Request has been Approved - %s';
$_['text_changed']	= 'Product Update Request has been Approved ';
$_['text_product']	= 'Product: %s';
$_['text_operator']	= 'Operator: %s';
$_['text_new_price'] = 'New Price: %s';
$_['text_new_regular_price'] = 'New Regular Price: %s';
$_['text_new_status']= 'New Status: %s';
$_['text_new_sort_order']= 'New Sort Order: %s';
$_['text_price'] = 'Old Price: %s';
$_['text_status']= 'Old Status: %s';
$_['text_sort_order']= 'New Sort Order: %s';