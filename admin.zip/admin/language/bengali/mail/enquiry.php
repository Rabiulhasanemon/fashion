<?php
// Text
$_['text_subject']	= 'Re: Enquiry %s - %s';