<?php
// Text
$_['text_approve_subject']      = '%s - Your Operator Account has been activated!';
$_['text_approve_welcome']      = 'Welcome and thank you for registering at %s!';
$_['text_approve_login']        = 'Your operator account has now been created and you can log in by using your email address and password by visiting our website or at the following URL:';
$_['text_approve_thanks']       = 'Thanks,';