<?php
// Text
$_['text_subject']       = '%s - RMA Update %s';
$_['text_return_id']     = 'RMA ID:';
$_['text_date_added']    = 'RMA Date:';
$_['text_return_status'] = 'Your return has been updated to the following status:';
$_['text_comment']       = 'The comments for your return are:';
$_['text_footer']        = 'Please reply to this email if you have any questions.';