<?php
// Text
$_['text_footer'] 	= 'Lark &copy; 2009-' . date('Y') . ' All Rights Reserved.';
$_['text_version'] 	= 'Version %s';