<?php
// Heading
$_['heading_title'] = 'Total Readers';

// Text
$_['text_view'] = 'View more...';