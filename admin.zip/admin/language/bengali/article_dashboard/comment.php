<?php
// Heading
$_['heading_title'] = 'Total Comment';

// Text
$_['text_view']     = 'View more...';