<?php
// Heading
$_['heading_title']     = 'Latest Articles';

// Column
$_['column_article_id']   = 'Article ID';
$_['column_title']   = 'Title';
$_['column_status']     = 'Status';
$_['column_date_added'] = 'Date Added';
$_['column_action']     = 'Action';