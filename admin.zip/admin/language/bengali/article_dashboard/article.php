<?php
// Heading
$_['heading_title'] = 'Total Articles';

// Text
$_['text_view']     = 'View more...';